python文件:
request.py
用于爬取教务处电信学部课程和全校课程

change.py
用于消除课程中的重复行

student.py 
allstudent.py
生成学生信息和成绩信息

sc.java 
course.java
student.java
JDBC：用于导入目标数据

sql.sql
实验过程中书写的sql语句（未更新，以实验报告为准）